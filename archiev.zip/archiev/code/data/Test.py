import os, sys

def hello_print():
    print("hello, python")